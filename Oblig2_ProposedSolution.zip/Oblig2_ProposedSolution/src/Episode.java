public class Episode {
    private String tittel;
    private int episodeNr, sesongNr, spilletid;

    /**
     * Konstruktør for Episode
     * @param tittel - tittelen til episoden
     * @param episodeNr - episodenummeret til episoden (i denne sesongen)
     * @param sesongNr - sesongnummeret til episoden
     */
    public Episode(String tittel, int episodeNr, int sesongNr) {
        // Kaller den andre konstruktøren, sender parameterne videre, men setter spilletid til 0
        this(tittel, episodeNr, sesongNr, 0);
    }

    /**
     * Konstruktør for Episode
     * @param tittel - tittelen til episoden
     * @param episodeNr - episodenummeret til episoden (i denne sesongen)
     * @param sesongNr - sesongnummeret til episoden
     * @param spilletid - spilletid i minutter
     */
    public Episode(String tittel, int episodeNr, int sesongNr, int spilletid) {
        this.tittel = tittel;
        this.episodeNr = episodeNr;
        this.sesongNr = sesongNr;
        this.spilletid = spilletid;
    }

    public int getEpisodeNr() {
        return episodeNr;
    }

    public void setEpisodeNr(int episodeNr) {
        this.episodeNr = episodeNr;
    }

    public int getSesongNr() {
        return sesongNr;
    }

    public void setSesongNr(int sesongNr) {
        this.sesongNr = sesongNr;
    }

    public int getSpilletid() {
        return spilletid;
    }

    public void setSpilletid(int spilletid) {
        this.spilletid = spilletid;
    }

    public String getTittel() {
        return tittel;
    }

    public void setTittel(String tittel) {
        this.tittel = tittel;
    }

    /**
     * Genererer en string for Episode
     * @return String i formen "NavnPåEpisode - S01E03 - Spilletid: 25"
     */
    @Override
    public String toString() {
        // String format legger her bare på 0 foran, slik at vi f.eks. får det på formatet 03 fremfor bare 3
        return tittel + " - S" + String.format("%02d", sesongNr) + "E" + String.format("%02d", episodeNr) + " - Spilletid: " + spilletid;
    }
}
